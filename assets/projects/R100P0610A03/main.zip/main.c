#include <GLFW/glfw3.h>

extern void render_process();

int main(int argc, char *argv[]) {
	if (glfwInit() != GLFW_TRUE) {
		return 1;
	}

	GLFWwindow *window = glfwCreateWindow(640, 480, "GLFW, and ASM", NULL, NULL);
	glfwMakeContextCurrent(window);

	while (!glfwWindowShouldClose(window)) {
		render_process();
		glfwSwapBuffers(window);
		glfwPollEvents();
	}
	glfwTerminate();

	return 0;
}

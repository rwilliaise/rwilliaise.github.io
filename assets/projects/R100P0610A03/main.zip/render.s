
	.global render_process
	.text

one: .float 1.0

render_process:
	push	%rbp
	mov	%rsp, %rbp
	# glClearColor(1.0f, 0.0f, 0.0f, 1.0f);
	movss 	one(%rip), %xmm0 	# 1.0
	pxor 	%xmm1, %xmm1		# 0.0
	pxor 	%xmm2, %xmm2		# 0.0
	movss 	one(%rip), %xmm3	# 1.0
	call 	glClearColor
	# glClear(GL_COLOR_BUFFER_BIT)
	mov 	$0x00004000, %rdi
	call 	glClear
	leave
	ret

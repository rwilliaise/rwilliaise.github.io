	.global main
	.section .rodata

.T: .string "Hello, world!"

	.text

main:
	leaq 	.T(%rip), %rdi
	call 	puts
	xor	%al, %al
	ret

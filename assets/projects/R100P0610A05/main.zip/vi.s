	.global main
	.section .rodata

.T: .string "Hello, world"

	.text

main:
	lea	.T(%rip), %rdi
	call	puts
	xor	%al, %al
	ret
